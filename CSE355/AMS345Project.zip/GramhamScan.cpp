//Zhiming Fan 110761374
#include <iostream> 
#include <stack> 
#include <stdlib.h> 
#include <fstream>
#include <string>
#include <algorithm>
using namespace std;
//Build class for coordinates
class Point
{
public:
	int getX();
	int getY();
	void setX(int);
	void setY(int);
private:
	int x, y;
};
void Point::setX(int i) {
	x = i;
}
void Point::setY(int j) {
	y = j;
}
int Point::getX(){
	return x;
}
int Point::getY() {
	return y;
}
//Reference point.
Point REF;
int distance(Point i, Point j);
int orientation(Point p, Point q, Point r);
int compare(const void *vp1, const void *vp2);
void swap(Point &i, Point &j);
Point second(stack<Point> &S);
int orientation(Point i, Point j, Point r)
{
	int val = (j.getY() - i.getY()) * (r.getX() - j.getX()) - (j.getX() - i.getX()) * (r.getY() - j.getY());
	if (val == 0) {
		return 0;
	}
	return (val > 0) ? 1 : 2;
}
int compare(const void *vp1, const void *vp2)
{
	Point *p1 = (Point *)vp1;
	Point *p2 = (Point *)vp2;
	int o = orientation(REF, *p1, *p2);
	if (o == 0)
		return (distance(REF, *p2) >= distance(REF, *p1)) ? -1 : 1;
	return (o == 2) ? -1 : 1;
}
int distance(Point i, Point j)
{
	return (i.getX() - j.getX())*(i.getX() - j.getX()) + (i.getY() - j.getY())*(i.getY() - j.getY());
}
void swap(Point &i, Point &j)
{
	Point temp = i;
	i = j;
	j = temp;
}
Point second(stack<Point> &S)
{
	Point p = S.top();
	S.pop();
	Point res = S.top();
	S.push(p);
	return res;
}
int main()
{
	ifstream inFile;
	ofstream outFile;
	inFile.open("input.txt");
	outFile.open("output.txt");
	int matrix[100][2];
	int t = 0;
	if (!inFile) {
		outFile << "Unable to open file";
		exit(1);
	}
	else {
		string str;
		inFile >> t;
		int loop = 0;
		while (!inFile.eof())
		{
			getline(inFile, str);
			replace(str.begin(), str.end(), ',',' ');
			str.erase(remove(str.begin(), str.end(), '['), str.end());
			str.erase(remove(str.begin(), str.end(), ']'), str.end());
			int index = str.find(" ",0);
			string one = str.substr(0, index);
			string two = str.substr(index+1, str.length());
			signed int i = atoi(one.c_str());
			signed int j = atoi(two.c_str());
			if (loop == 0) {
				loop++;
				continue;
			}
			else {
				matrix[loop-1][0] = i;
				matrix[loop-1][1] = j;
			}
			loop++;
		}
	}
	Point *data;
	data = new Point[t];
	for (int i = 0; i < t; i++) {
		data[i].setX(matrix[i][0]);
		data[i].setY(matrix[i][1]);
	}
	int ymin = data[0].getY();
	int min = 0;
	for (int i = 1; i < t; i++)
	{
		int y = data[i].getY();
		if ((y < ymin) || (ymin == y && data[i].getX() < data[min].getX())) {
			ymin = data[i].getY();
			min = i;
		}
	}
	swap(data[min], data[0]);
	REF = data[0];
	qsort(&data[1], t - 1, sizeof(Point), compare);
	int m = 1;
	for (int i = 1; i < t; i++)
	{
		while (i < t - 1 && orientation(REF, data[i], data[i + 1]) == 0)
			i++;
		data[m] = data[i];
		m++;
	}
	if (m < 3) {
		outFile << "No enough points to construct convex hull" << endl;
		exit(0);
	}
	stack<Point> Stack;
	stack<Point> CounterclockwiseOrder;
	int temp = 0;
	do {
		Stack.push(data[temp]);
		temp++;
	} while (temp != 3);
	for (int i = temp; i < m; i++)
	{
		Point H = Stack.top();
		while (orientation(second(Stack), Stack.top(), data[i]) != 2) {
			Stack.pop();
		}
		Stack.push(data[i]);
	}
	outFile << Stack.size() << endl;
	while (true)
	{	
		if (Stack.empty()) {
			break;
		}
		Point p = Stack.top();
		CounterclockwiseOrder.push(p);
		Stack.pop();
	}
	while(true){
		if (CounterclockwiseOrder.empty()) {
			break;
		}
		Point G = CounterclockwiseOrder.top();
		outFile << "[" << G.getX() << ", " << G.getY() << "]" << endl;
		CounterclockwiseOrder.pop();
	}
	delete[] data;
	inFile.close();
	outFile.close();
	return 0;
}